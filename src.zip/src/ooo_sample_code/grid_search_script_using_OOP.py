import numpy as np
import pandas as pd
#import matplotlib
#import matplotlib.pyplot as plt
import os
import random as rnd



#import numpy as np

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import FeatureUnion
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.linear_model import Lasso
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import OneHotEncoder

from sklearn.metrics import mean_squared_error
#from sklearn.cross_validation import cross_validation
from sklearn.cross_validation import KFold

from sklearn.linear_model import SGDRegressor
from scipy.stats import describe
from sklearn.svm import SVR

from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import Imputer

from sklearn.ensemble import GradientBoostingRegressor
from sklearn.grid_search import GridSearchCV

from sklearn.metrics import make_scorer

from pprint import pprint
from time import time
#import logging

#pd.options.display.mpl_style = 'default'

PREFIX = '../input/'

train = None


class ItemSelector(BaseEstimator, TransformerMixin):

    def __init__(self, key):
        self.key = key

    def fit(self, x, y=None):
        return self

    def transform(self, data_dict):
        #print data_dict.shape
        
        r = np.array(data_dict[self.key]).reshape(-1, 1)
        return r
    

class FeatureImputer(BaseEstimator, TransformerMixin):
    def __init__(self, key):
        self.key = key

    def fit(self, x, y=None):
        return self

    def transform(self, data_dict):
        #print data_dict.shape
        
        raw = np.array(data_dict[self.key]).reshape(-1, 1)
        inds = np.where(np.isnan(raw))[0]
      
        r = np.zeros((raw.shape[0], 2))
        r[:,0] = raw.reshape(-1)
        r[inds, 0] = -1
        r[inds, 1] = 1
        return r
    
    
class DictTransformer(BaseEstimator, TransformerMixin):
    def fit(self, x, y=None):
        return self
    
    def transform(self, data):
        
        r = data.to_dict('list')
        return r
    

class TableMerger(BaseEstimator, TransformerMixin):
    
    def __init__(self, table=None, join_key=None):
        self.table = table
        self.join_key = join_key
        
    def fit(self, x, y=None):
        return self
    
    def transform(self, data):        
        return pd.merge(data, self.table, on=self.join_key, how='left')
    

class DebugOut(BaseEstimator, TransformerMixin):
    
    def fit(self, x, y=None):
        return self
    
    def transform(self, data):
        print(data[:5])
        print('Shape: ' + str(data.shape))
        return data
        
class PCAPlot(BaseEstimator, TransformerMixin):
    
    def __init__(self, pca=None):
        self.pca = pca
     
    def fit(self, x, y=None):
        return self
    
    def transform(self, data):
        #data = data.toarray()
        pca.fit(data)
        #plt.figure(1, figsize=(4, 3))
       # plt.clf()
        #plt.xlim([0, 50])
      #  plt.plot(pca.explained_variance_, linewidth=2)
       # plt.xlabel('n_components')
     #   plt.ylabel('explained_variance_')
        return data
    

class DenseTransformer(TransformerMixin):

    def transform(self, X, y=None, **fit_params):
        return X.todense()

    def fit_transform(self, X, y=None, **fit_params):
        self.fit(X, y, **fit_params)
        return self.transform(X)

    def fit(self, X, y=None, **fit_params):
        return self

    
def log1pMSE(ground_truth, predictions):
    y_pred = np.maximum(0, predictions)
    return metrics.mean_squared_error(np.log1p(ground_truth), np.log1p(y_pred), multioutput='uniform_average')
    
def cl_averages():
    df_train = load_train(['Venta_hoy', 'Dev_proxima'])
    
    df = df_train.groupby(['Cliente_ID','Semana'])['Venta_hoy', 'Dev_proxima'].sum()
    df = df.reset_index().groupby(['Cliente_ID'])['Venta_hoy'].agg(['min', 'max','median']).add_prefix('Client_venta_')
    df = df.reset_index()[['Cliente_ID','Client_venta_max', 'Client_venta_min','Client_venta_median']]
    
    df_train = df_train.merge(df, on=['Cliente_ID'], how='left')
    del(df)
    
    return df_train
    
def cl_prod_venta_averages():
    df_train = load_train(['Venta_uni_hoy'])
    
    df = df_train[df_train.Venta_uni_hoy > 0].groupby(['Cliente_ID', 'Producto_ID', 'Semana'])['Venta_uni_hoy'].sum()
    df = df.reset_index()
    df = df.groupby(['Cliente_ID', 'Producto_ID'])['Venta_uni_hoy'].agg(['min', 'max','median']).add_prefix('Venta_uni_') 

    df = df.reset_index()[['Cliente_ID', 'Producto_ID', 'Venta_uni_max', 'Venta_uni_min','Venta_uni_median']]
    
    df_train = df_train.merge(df, on=['Cliente_ID', 'Producto_ID'], how='left')
    del(df)
    return df_train        

def cl_prod_dev_averages():
    df_train = load_train(['Venta_uni_hoy', 'Dev_uni_proxima'])
    
    df = df_train[df_train.Venta_uni_hoy > 0].groupby(['Cliente_ID', 'Producto_ID', 'Semana'])['Dev_uni_proxima'].sum()
    df = df.reset_index()
    df = df.groupby(['Cliente_ID', 'Producto_ID'])['Dev_uni_proxima'].agg(['min', 'max','median']).add_prefix('Dev_uni_') 

    df = df.reset_index()[['Cliente_ID', 'Producto_ID', 'Dev_uni_max', 'Dev_uni_min','Dev_uni_median']]
    
    df_train = df_train.merge(df, on=['Cliente_ID', 'Producto_ID'], how='left')
    del(df)
    
    return df_train 


def process_products(products):
    
    ### TODO: use converters
    products.NombreProducto = products.NombreProducto.str.lower()
    #products['short_name'] = products.NombreProducto.str.extract('^(\D*)', expand=False)
    #products['brand'] = products.NombreProducto.str.extract('^.+\s(\D+) \d+$', expand=False)
    
    products['pieces'] =  products.NombreProducto.str.extract('(\d+)p ', expand=False).astype('float')
    products.loc[np.isnan(products.pieces), 'pieces'] = 1

    w = products.NombreProducto.str.extract('(\d+)(kg|g|ml)', expand=True)
    products['weight'] = w[0].astype('float')*w[1].map({'kg':1000, 'g':1, 'ml':1})
    products['weight_not_present'] = products['weight'].apply (lambda val: 1 if np.isnan(val) else 0)
    products.loc[np.isnan(products.weight), 'weight'] = 0
    
    
    #df1 = df_main.groupby(['Producto_ID'])[['price']].median()
    #df1 = df1.add_suffix('_m').reset_index()
        
    #products = products.merge(df1, on='Producto_ID', how='left')
        
    return products
    
def load_clients():
    return pd.read_csv(PREFIX + 'cliente_tabla.csv')
    
def load_agencies():
    return pd.read_csv(PREFIX + 'town_state.csv')
    
    
def load_train(cols):
    if (train is None):
        df_train = pd.read_csv(PREFIX + 'train.csv', usecols = ['Semana', 'Cliente_ID', 'Producto_ID'] + cols,
                           dtype  = {'Semana': 'int32',
                                     'Cliente_ID':'int32',
                                     'Producto_ID':'int32',
                                     'Venta_hoy':'float32',
                                     'Venta_uni_hoy': 'int32',
                                     'Dev_uni_proxima':'int32',
                                     'Dev_proxima':'float32',
                                     'Demanda_uni_equil':'int32'})
    else:
        df_train = train
    return df_train
    
def calculate_price(train):
    df_main = load_train(['Venta_hoy', 'Venta_uni_hoy'])
    train['price_v'] = df_main['Venta_hoy']/df_main['Venta_uni_hoy']
    del(df_main)

    df_main = load_train(['Dev_proxima', 'Dev_uni_proxima'])
    train['price_d'] = df_main['Dev_proxima']/df_main['Dev_uni_proxima']
    del(df_main)

    train['price'] = np.fmax(train['price_v'], train['price_d'])
    train.drop('price_v', axis=1, inplace = True)
    train.drop('price_d', axis=1, inplace = True)
    
    return train
    
#pca = decomposition.PCA()
#sgd = SGDRegressor(alpha=0.0001, average=False, epsilon=0.1, eta0=0.01,
#             fit_intercept=True, l1_ratio=0.15, learning_rate='invscaling',             
#             loss='squared_loss', n_iter=5, penalty='l2', power_t=0.25,
#             random_state=None, shuffle=True, verbose=0, warm_start=False)

#gbr = GradientBoostingRegressor(n_estimators=100, learning_rate=1.0, max_depth=2, random_state=0)
t0 = time()
print('Loading train data')

train = load_train(['Venta_hoy', 'Venta_uni_hoy', 
        'Dev_proxima',  'Dev_uni_proxima', 'Demanda_uni_equil'])
#print("done in %0.3fs" % (time() - t0))
#calculate_price(train)
#print("done in %0.3fs" % (time() - t0))
#train = train[train['Semana'] < 9]
print("done in %0.3fs" % (time() - t0))

print('Loading products')
products = pd.read_csv(PREFIX + 'producto_tabla.csv')
products = process_products(products)    
print("done in %0.3fs" % (time() - t0))

print('Loading client_prod venta averages')
#cl_prod_venta_avg_table = cl_prod_venta_averages()
train = cl_prod_venta_averages()
print("done in %0.3fs" % (time() - t0))

print('Loading client_prod dev avergages')
train = cl_prod_dev_averages()
print("done in %0.3fs" % (time() - t0))

print('Loading clients averages')
train = cl_averages()
print("done in %0.3fs" % (time() - t0))

pipeline = Pipeline([

    #('d1', DebugOut()),
    # Use FeatureUnion to combine the features 
    ('union', FeatureUnion(
        transformer_list=[
            
            #('Semana', Pipeline([
            #    ('selector', ItemSelector(key='Semana')),
            #])),  

            # Pipeline for pulling features from the post's subject line
            ('weight', Pipeline([
                ('selector', ItemSelector(key='weight')),
            ])),
            ('weight_not_present', ItemSelector(key='weight_not_present')),

            ('cl_prod_venta_uni_max', Pipeline([
                ('selector', FeatureImputer(key='Venta_uni_max')),
            ])),

            ('cl_prod_venta_uni_min', Pipeline([
                ('selector', FeatureImputer(key='Venta_uni_min')),
              ])),

            ('cl_prod_venta_uni_median', Pipeline([
                ('selector', FeatureImputer(key='Venta_uni_median')),
             ])),  


            ('cl_prod_dev_uni_max', Pipeline([
                ('selector', FeatureImputer(key='Venta_uni_max')),
       
            ])),

            ('cl_prod_dev_uni_min', Pipeline([
                ('selector', FeatureImputer(key='Venta_uni_min')),
            ])),

            ('cl_prod_dev_uni_median', Pipeline([
                ('selector', FeatureImputer(key='Venta_uni_median')),
             ])),  

            ('Client_venta_min', Pipeline([
                ('selector', FeatureImputer(key='Client_venta_min')),
             ])),

            ('Client_venta_max', Pipeline([
                ('selector', FeatureImputer(key='Client_venta_max')),
                #('imputer', Imputer(missing_values='NaN',
                #                    strategy='median',
                #                    axis=0)),
            ])),
  

            ('Client_venta_median', Pipeline([
                ('selector', ItemSelector(key='Client_venta_median')),
                #('imputer', Imputer(missing_values='NaN',
                #                    strategy='median',
                #                    axis=0)),
            ])),
                  

            #('prod_price', Pipeline([
            #    ('selector', FeatureImputer(key='price')),
                #('imputer', Imputer(missing_values='NaN',
                #                    strategy='median',
                #                    axis=0)),
            #])),
        

        ],
    )),
    
    
    # Use a SVC classifier on the combined features
    #('to_dense', DenseTransformer()), 
    #('pca', decomposition.PCA(n_components=4)),
    #('pca_plot', PCAPlot(pca)),
   

    #('d2', DebugOut()),
    #('lasso', Lasso(fit_intercept=True)),
     ('gbr',   GradientBoostingRegressor(random_state=0, learning_rate=0.1, max_depth=3)),
    #('svm', SVR(kernel='rbf', C=1, gamma=0.1)),
])


parameters = {
    'gbr__n_estimators': (200, 300),
#    'gbr__learning_rate': (0.01, 0.1),  
#    'gbr__max_depth': (3, 4),
}


print('Selecting train colums')
X = train[['Semana','Cliente_ID','Producto_ID']]
y = np.array(train['Demanda_uni_equil'].tolist())
print("done in %0.3fs" % (time() - t0))

pre_pipeline = Pipeline([
    ('merge_products', TableMerger(products, 'Producto_ID')),
  #  ('merge_cl_prod_venta', TableMerger(cl_prod_venta_avg_table, ['Cliente_ID', 'Producto_ID'])),
  #  ('merge_cl_prod_dev', TableMerger(cl_prod_dev_avg_table, ['Cliente_ID', 'Producto_ID'])),
  #  ('merge_cl', TableMerger(cl_avg_table, 'Cliente_ID')),  
#    ('to_array', DictTransformer()),
])

print('Pre-pipeline merging')
X = pre_pipeline.transform(X)
print("done in %0.3fs" % (time() - t0))

grid_search = GridSearchCV(pipeline, parameters, scoring = make_scorer(log1pMSE, greater_is_better=False), 
                           n_jobs=3, verbose=1)

t0 = time()
print('Starting Grid Search')
grid_search.fit(X, y)
print("done in %0.3fs" % (time() - t0))
print()

print("Best score: %0.3f" % grid_search.best_score_)
print("Best parameters set:")
best_parameters = grid_search.best_estimator_.get_params()
for param_name in sorted(parameters.keys()):
    print("\t%s: %r" % (param_name, best_parameters[param_name]))


